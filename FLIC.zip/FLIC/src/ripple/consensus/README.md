# Consensus

This directory contains the implementation of a
generic consensus algorithm.  The implementation
follows a CRTP design, requiring client code to implement
specific functions and types to use consensus in their
application.  The interface is undergoing refactoring and
is not yet finalized.

