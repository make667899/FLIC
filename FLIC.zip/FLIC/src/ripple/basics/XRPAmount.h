//------------------------------------------------------------------------------
/*
    This file is part of rippled: https://github.com/ripple/rippled
    Copyright (c) 2012, 2013 Ripple Labs Inc.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose  with  or without fee is hereby granted, provided that the above
    copyright notice and this permission notice appear in all copies.

    THE  SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
    WITH  REGARD  TO  THIS  SOFTWARE  INCLUDING  ALL  IMPLIED  WARRANTIES  OF
    MERCHANTABILITY  AND  FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
    ANY  SPECIAL ,  DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
    WHATSOEVER  RESULTING  FROM  LOSS  OF USE, DATA OR PROFITS, WHETHER IN AN
    ACTION  OF  CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
    OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/
//==============================================================================

#ifndef RIPPLE_BASICS_FLICAMOUNT_H_INCLUDED
#define RIPPLE_BASICS_FLICAMOUNT_H_INCLUDED

#include <ripple/basics/contract.h>
#include <ripple/basics/safe_cast.h>
#include <ripple/beast/cxx17/type_traits.h>
#include <ripple/beast/utility/Zero.h>
#include <ripple/json/json_value.h>

#include <boost/operators.hpp>
#include <boost/optional.hpp>
#include <boost/multiprecision/cpp_int.hpp>

#include <cstdint>
#include <string>

namespace ripple {

namespace feeunit {

/** "drops" are the smallest divisible amount of FLIC. This is what most
    of the code uses. */
struct dropTag;

} // feeunit

class FLICAmount
    : private boost::totally_ordered <FLICAmount>
    , private boost::additive <FLICAmount>
    , private boost::equality_comparable <FLICAmount, std::int64_t>
    , private boost::additive <FLICAmount, std::int64_t>
{
public:
    using unit_type = feeunit::dropTag;
    using value_type = std::int64_t;
private:
    value_type drops_;

public:
    FLICAmount () = default;
    constexpr FLICAmount (FLICAmount const& other) = default;
    constexpr FLICAmount& operator= (FLICAmount const& other) = default;

    constexpr
    FLICAmount (beast::Zero)
        : drops_ (0)
    {
    }

    constexpr
    FLICAmount&
    operator= (beast::Zero)
    {
        drops_ = 0;
        return *this;
    }

    constexpr
    explicit
    FLICAmount (value_type drops)
        : drops_ (drops)
    {
    }

    FLICAmount&
    operator= (value_type drops)
    {
        drops_ = drops;
        return *this;
    }

    constexpr
    FLICAmount
    operator*(value_type const& rhs) const
    {
        return FLICAmount{ drops_ * rhs };
    }

    friend
    constexpr
    FLICAmount
    operator*(value_type lhs, FLICAmount const& rhs)
    {
        // multiplication is commutative
        return rhs * lhs;
    }

    FLICAmount&
    operator+= (FLICAmount const& other)
    {
        drops_ += other.drops();
        return *this;
    }

    FLICAmount&
    operator-= (FLICAmount const& other)
    {
        drops_ -= other.drops();
        return *this;
    }

    FLICAmount&
    operator+= (value_type const& rhs)
    {
        drops_ += rhs;
        return *this;
    }

    FLICAmount&
    operator-= (value_type const& rhs)
    {
        drops_ -= rhs;
        return *this;
    }

    FLICAmount&
    operator*= (value_type const& rhs)
    {
        drops_ *= rhs;
        return *this;
    }

    FLICAmount
    operator- () const
    {
        return FLICAmount{ -drops_ };
    }

    bool
    operator==(FLICAmount const& other) const
    {
        return drops_ == other.drops_;
    }

    bool
    operator==(value_type other) const
    {
        return drops_ == other;
    }

    bool
    operator<(FLICAmount const& other) const
    {
        return drops_ < other.drops_;
    }

    /** Returns true if the amount is not zero */
    explicit
    constexpr
    operator bool() const noexcept
    {
        return drops_ != 0;
    }

    /** Return the sign of the amount */
    constexpr
    int
    signum() const noexcept
    {
        return (drops_ < 0) ? -1 : (drops_ ? 1 : 0);
    }

    /** Returns the number of drops */
    constexpr
    value_type
    drops () const
    {
        return drops_;
    }

    constexpr
    double
    decimalFLIC () const;

    template <class Dest>
    boost::optional<Dest>
    dropsAs() const
    {
        if ((drops_ > std::numeric_limits<Dest>::max()) ||
            (!std::numeric_limits<Dest>::is_signed && drops_ < 0) ||
            (std::numeric_limits<Dest>::is_signed &&
            drops_ < std::numeric_limits<Dest>::lowest()))
        {
            return boost::none;
        }
        return static_cast<Dest>(drops_);
    }

    template <class Dest>
    Dest
    dropsAs(Dest defaultValue) const
    {
        return dropsAs<Dest>().value_or(defaultValue);
    }

    template <class Dest>
    Dest
    dropsAs(FLICAmount defaultValue) const
    {
        return dropsAs<Dest>().value_or(defaultValue.drops());
    }

    Json::Value
    jsonClipped() const
    {
        static_assert(std::is_signed_v<value_type> &&
            std::is_integral_v<value_type>,
            "Expected FLICAmount to be a signed integral type");

        constexpr auto min = std::numeric_limits<Json::Int>::min();
        constexpr auto max = std::numeric_limits<Json::Int>::max();

        if (drops_ < min)
            return min;
        if (drops_ > max)
            return max;
        return static_cast<Json::Int>(drops_);
    }

    /** Returns the underlying value. Code SHOULD NOT call this
        function unless the type has been abstracted away,
        e.g. in a templated function.
    */
    constexpr
    value_type
    value () const
    {
        return drops_;
    }

    friend
    std::istream&
    operator>> (std::istream& s, FLICAmount& val)
    {
        s >> val.drops_;
        return s;
    }

};

/** Number of drops per 1 FLIC */
constexpr
FLICAmount
DROPS_PER_FLIC{1'000'000};

constexpr
double
FLICAmount::decimalFLIC () const
{
    return static_cast<double>(drops_) / DROPS_PER_FLIC.drops();
}

// Output FLICAmount as just the drops value.
template<class Char, class Traits>
std::basic_ostream<Char, Traits>&
operator<<(std::basic_ostream<Char, Traits>& os,
    const FLICAmount& q)
{
    return os << q.drops();
}

inline
std::string
to_string (FLICAmount const& amount)
{
    return std::to_string (amount.drops ());
}

inline
FLICAmount
mulRatio (
    FLICAmount const& amt,
    std::uint32_t num,
    std::uint32_t den,
    bool roundUp)
{
    using namespace boost::multiprecision;

    if (!den)
        Throw<std::runtime_error> ("division by zero");

    int128_t const amt128 (amt.drops ());
    auto const neg = amt.drops () < 0;
    auto const m = amt128 * num;
    auto r = m / den;
    if (m % den)
    {
        if (!neg && roundUp)
            r += 1;
        if (neg && !roundUp)
            r -= 1;
    }
    if (r > std::numeric_limits<FLICAmount::value_type>::max ())
        Throw<std::overflow_error> ("FLIC mulRatio overflow");
    return FLICAmount (r.convert_to<FLICAmount::value_type> ());
}

}

#endif // RIPPLE_BASICS_FLICAMOUNT_H_INCLUDED
